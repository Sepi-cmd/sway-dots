#!/bin/bash

# Create the directory if it doesn't exist
mkdir -p ~/Pictures/Screenshots/Sway

# Take a screenshot
FILENAME=~/Pictures/Screenshots/Sway/screenshot-$(date +'%Y-%m-%d-%H%M%S').png
grim $FILENAME

# Copy the screenshot to the clipboard
wl-copy < $FILENAME

